package guviFirstProject;

public class Loops {

	public static void main(String[] args) {
		loopimplementation();
	}

	public static void loopimplementation() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("Welcome to Guvi");
		}

	}

}
