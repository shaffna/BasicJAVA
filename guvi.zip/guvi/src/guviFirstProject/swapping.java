package guviFirstProject;

import java.util.Scanner;

public class swapping {

	public static void main(String[] args) {
		swap();
	}

	public static void swap() {

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the first number: ");
		int num1 = scanner.nextInt();
		System.out.print("Enter the second number: ");
		int num2 = scanner.nextInt();

		int temp = num1;
		num1 = num2;
		num2 = temp;

		System.out.println("After swapping: First number = " + num1 + ", Second number = " + num2);

		scanner.close();

	}

}
