package guviFirstProject;

public class printAlphabets {

	public static void main(String[] args) {

		atoz();
	}

	public static void atoz() {
		for (char ch = 'A'; ch <= 'Z'; ch++) {
			System.out.print(ch +" ");
		}
	}
}