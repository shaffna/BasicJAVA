package guviFirstProject;

import java.util.Scanner;

public class Integer {

	public static void main(String[] args) {
		countnumber();
	}

	public static void countnumber() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int a = scanner.nextInt();
		int count = 0;

		while (a != 0) {
			a /= 10;
			count++;

		}
		System.out.println("Number of digits:" + count);
		scanner.close();
	}

}
