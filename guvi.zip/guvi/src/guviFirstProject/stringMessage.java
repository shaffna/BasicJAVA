package guviFirstProject;

public class stringMessage {

	public static void main(java.lang.String[] args) {
		stringprogram();
	}

	public static void stringprogram() {
		String name = "Guvi Geek";
		System.out.println("The length of the string \"" + name + "\" is:  " + name.length());
	}

}
