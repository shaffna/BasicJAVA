package guviFirstProject;

import java.util.Scanner;

public class PrintAge {

	public static void main(String[] args) {
		ageseniorcitizen();
	}

	public static void ageseniorcitizen() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your age: ");
		int age = scanner.nextInt();

		if (age >= 60) {
			System.out.println("The person is a senior citizen");
		} else {
			System.out.println("The person is not a senior citizen");
		}
		scanner.close();
	}

}
