package guviFirstProject;

import java.util.Scanner;

public class Introductionofjava {

	public static void main(String[] args) {

		firstifstatement();
	}

	public static void firstifstatement() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter value 'a': ");
		int a = scanner.nextInt();
		System.out.print("Enter value 'b': ");
		int b = scanner.nextInt();
		System.out.print("Enter value 'c': ");
		int c = scanner.nextInt();
		System.out.print("Enter value 'd': ");
		int d = scanner.nextInt();

		if ((a + b) > (c + d)) {
			System.out.println("The sum of a and b is greater than the sum of c and d.");
		} else {
			System.out.println("The sum of a and b is not greater than the sum of c and d.");
		}
		scanner.close();
	}
}
