package guviFirstProject;

import java.util.Scanner;

public class evenNumber {

	public static void main(String[] args) {

		even();
	}

	public static void even() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = scanner.nextInt();

		if (num % 2 == 0) {
			System.out.println("Given number is even.");
		} else {
			System.out.println("Given number is odd.");

		}
		scanner.close();
	}
}
